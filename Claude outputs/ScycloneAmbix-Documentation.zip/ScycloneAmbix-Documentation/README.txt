ScycloneAmbix - Technical Documentation
Christoffer Schöne, November 2026

main.pdf        the compiled document (38 pages)
main.tex        title page, colophon, chapter list
rysum.sty       the Rysum print style (fonts, rules, lozenges, rubric initials)
chapters/       one file per chapter
fonts/          Rysum Fell Roman/Italic (SIL OFL, see OFL_IMFell.txt)
figures/        grain texture for the title page

Build (XeLaTeX is required for the fonts):
    xelatex main.tex
    xelatex main.tex        (second run for contents and references)
or  latexmk -xelatex main.tex
